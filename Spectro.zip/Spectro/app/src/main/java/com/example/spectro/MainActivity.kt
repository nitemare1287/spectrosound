package com.example.spectro

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlin.math.*

const val N = 4096   // FFT size
const val W = 512    // spectrogram width (px)
const val H = 256    // spectrogram history (rows)

class Analyzer {
    val sr = 48000
    @Volatile var lo = 0f
    @Volatile var hi = sr / 2f
    @Volatile private var active = false
    val spec = mutableStateOf(FloatArray(N / 2) { -120f })
    val shot = mutableStateOf<ImageBitmap?>(null)
    private val pix = IntArray(W * H) { 0xFF000000.toInt() }
    private val win = FloatArray(N) { (0.5 - 0.5 * cos(2 * PI * it / (N - 1))).toFloat() }

    fun setRange(low: Float) { lo = low; hi = sr / 2f; pix.fill(0xFF000000.toInt()) }

    fun start() {
        if (active) return
        active = true
        Thread {
            val ch = AudioFormat.CHANNEL_IN_MONO
            val enc = AudioFormat.ENCODING_PCM_16BIT
            val buf = maxOf(AudioRecord.getMinBufferSize(sr, ch, enc), N * 4)
            fun open(src: Int) = runCatching {
                AudioRecord(src, sr, ch, enc, buf).takeIf { it.state == AudioRecord.STATE_INITIALIZED }
            }.getOrNull()
            // UNPROCESSED skips AGC/noise suppression, which matters for faint or ultrasonic signals
            val rec = open(MediaRecorder.AudioSource.UNPROCESSED)
                ?: open(MediaRecorder.AudioSource.MIC) ?: run { active = false; return@Thread }
            rec.startRecording()
            val hop = N / 2
            val s = ShortArray(hop); val x = FloatArray(N)
            val re = FloatArray(N); val im = FloatArray(N)
            while (active) {
                val n = rec.read(s, 0, hop)
                if (n <= 0) continue
                System.arraycopy(x, n, x, 0, N - n)
                for (i in 0 until n) x[N - n + i] = s[i] / 32768f
                for (i in 0 until N) { re[i] = x[i] * win[i]; im[i] = 0f }
                fft(re, im)
                val db = FloatArray(N / 2) { 20f * log10(hypot(re[it], im[it]) * 4f / N + 1e-9f) }
                push(db)
                spec.value = db
            }
            rec.stop(); rec.release()
        }.start()
    }

    fun stop() { active = false }

    private fun push(db: FloatArray) {
        System.arraycopy(pix, W, pix, 0, W * (H - 1))
        val bw = sr.toFloat() / N
        for (px in 0 until W) {
            val f = lo + (hi - lo) * px / W
            val v = ((db[(f / bw).toInt().coerceIn(0, N / 2 - 1)] + 110f) / 90f).coerceIn(0f, 1f)
            pix[W * (H - 1) + px] = heat(v)
        }
        shot.value = Bitmap.createBitmap(pix, W, H, Bitmap.Config.ARGB_8888).asImageBitmap()
    }

    private fun heat(v: Float): Int {
        val r = (v * 3 - 1).coerceIn(0f, 1f); val g = (v * 3 - 2).coerceIn(0f, 1f)
        val b = if (v < .33f) v * 3 else (2 - v * 3).coerceIn(0f, 1f)
        return (0xFF shl 24) or ((r * 255).toInt() shl 16) or ((g * 255).toInt() shl 8) or (b * 255).toInt()
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        var j = 0
        for (i in 1 until N) {
            var bit = N shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t }
        }
        var len = 2
        while (len <= N) {
            val ang = -2 * PI / len
            val wr = cos(ang).toFloat(); val wi = sin(ang).toFloat()
            var i = 0
            while (i < N) {
                var cr = 1f; var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k; val b = a + len / 2
                    val tr = re[b] * cr - im[b] * ci; val ti = re[b] * ci + im[b] * cr
                    re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti
                    val nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr
                }
                i += len
            }
            len = len shl 1
        }
    }
}

class MainActivity : ComponentActivity() {
    private val an = Analyzer()
    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) an.start() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App(an) } }
    }

    override fun onStart() {
        super.onStart()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) an.start()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }

    override fun onStop() { super.onStop(); an.stop() }
}

@Composable
fun App(an: Analyzer) {
    var ultra by remember { mutableStateOf(false) }
    LaunchedEffect(ultra) { an.setRange(if (ultra) 15000f else 0f) }
    val spec by an.spec
    val img by an.shot
    val bw = an.sr.toFloat() / N
    var pk = (an.lo / bw).toInt().coerceIn(1, N / 2 - 1)
    for (b in pk until N / 2) if (spec[b] > spec[pk]) pk = b

    Column(
        Modifier.fillMaxSize().background(Color.Black).windowInsetsPadding(WindowInsets.safeDrawing).padding(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Peak %.0f Hz  %.0f dB".format(pk * bw, spec[pk]), color = Color.White)
            Button(onClick = { ultra = !ultra }) { Text(if (ultra) "Full range" else "Ultrasonic 15k+") }
        }
        Canvas(Modifier.fillMaxWidth().height(180.dp)) {
            val p = Path()
            for (x in 0 until size.width.toInt() step 2) {
                val f = an.lo + (an.hi - an.lo) * x / size.width
                val b = (f / bw).toInt().coerceIn(0, N / 2 - 1)
                val y = size.height * (1 - ((spec[b] + 110f) / 90f).coerceIn(0f, 1f))
                if (x == 0) p.moveTo(0f, y) else p.lineTo(x.toFloat(), y)
            }
            drawPath(p, Color.Green, style = Stroke(2f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            val mid = (an.lo + an.hi) / 2
            Text("%.1f kHz".format(an.lo / 1000), color = Color.Gray)
            Text("%.1f kHz".format(mid / 1000), color = Color.Gray)
            Text("%.1f kHz".format(an.hi / 1000), color = Color.Gray)
        }
        img?.let { Image(it, null, Modifier.fillMaxWidth().weight(1f), contentScale = ContentScale.FillBounds) }
    }
}
