Spectro: real-time spectrum + scrolling spectrogram (Kotlin, Jetpack Compose).
Build: open this folder in Android Studio (it creates the Gradle wrapper), then Run.
CLI: run `gradle wrapper` once, then `./gradlew assembleDebug`.
Targets Android 8+ (minSdk 26), compileSdk/targetSdk 35. 48 kHz capture, so the display tops out at 24 kHz.
